export type TimeblockTask = {
	id: string;
	name: string;
	description: string;
};