export enum AuthenticationMethod {
	cookie = 'cookie',
	header = 'header',
}
