module.exports = {
	extends: [require.resolve('@leonzalion/configs/eslint.cjs')],
};
