module.exports = require('@leonzalion/configs/markdownlint.cjs');
