import { prePush } from 'lion-system';

prePush();
