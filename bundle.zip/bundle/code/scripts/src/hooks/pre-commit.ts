import { preCommit } from 'lion-system';

preCommit();
