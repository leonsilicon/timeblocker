import { commitMsg } from 'lion-system';

commitMsg();
