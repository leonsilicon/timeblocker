module.exports = {
	folders: ['src/utils', 'src/types'],
};
