-- AlterTable
ALTER TABLE "TimeblockTask" ADD COLUMN     "isHidden" BOOLEAN NOT NULL DEFAULT false;
