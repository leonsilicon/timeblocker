-- AlterTable
ALTER TABLE "TimeblockTaskBlock" ADD COLUMN     "type" TEXT NOT NULL DEFAULT E'normal';
