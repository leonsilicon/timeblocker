import type { getAppRouter } from '~b/routes/router.js';

export type AppRouter = ReturnType<typeof getAppRouter>;
