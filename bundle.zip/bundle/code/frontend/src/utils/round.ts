export function roundToNearest15(n: number) {
	return Math.round(n / 15) * 15;
}
