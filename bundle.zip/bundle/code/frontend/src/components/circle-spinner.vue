<template>
	<div class="spinner-border h-6 w-6 animate-spin rounded-full"></div>
</template>
