<template>
	<div class="column center h-full w-full">
		<div class="text-6xl font-bold">404</div>
		<div class="mt-2">
			Page not found.
			<router-link class="text-blue-400 underline hover:text-blue-500" to="/">
				Click here to return home.
			</router-link>
		</div>
	</div>
</template>
