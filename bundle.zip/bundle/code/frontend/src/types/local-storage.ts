export enum LocalStorageKey {
	sessionToken = 'session-token',
}
