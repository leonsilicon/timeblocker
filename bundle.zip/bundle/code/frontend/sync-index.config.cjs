module.exports = {
	folders: ['src/types', 'src/utils'],
	exportExtensions: false,
};
